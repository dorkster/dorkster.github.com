#!/bin/bash

savedir=~/Scripts/downloaded_images

if [ $# -lt 1 ]
then
    echo "Error: No arguments given."
    exit 1
fi

if ! echo $1 | grep "^http://"
then
    echo "Error: Argument was not a url."
    exit 1
fi

url=$1

mkdir -p $savedir
cd $savedir

wget -O - $url | \
grep -o '<a href=['"'"'"][^"'"'"']*['"'"'"]' | \
sed -e 's/^<a href=["'"'"']//' -e 's/["'"'"']$//' | \
# Remove double slashes (4chan uses these now)
sed -e 's/^\/\///' >> urls.txt

grep png urls.txt >> images.txt
grep jpg urls.txt >> images.txt
grep gif urls.txt >> images.txt

for i in $(cat images.txt); do wget -nc -nv $i; done

rm ./images.txt
rm ./urls.txt
rm -f ./*.html*

echo "Scrape Completed."

exit 0
