#!/bin/bash
if [ -s ~/.newsbeuter/urls ]; then
newsbeuter -x reload
query=$(newsbeuter -x print-unread | grep -w "unread articles")
if echo $query | grep -wq "0 unread articles"; then
    echo "No new articles."
    exit
else
    echo "$query"
    DISPLAY=:0.0 XAUTHORITY=~/.Xauthority \
    notify-send "Newsbeuter" "$query" -i liferea
fi
fi
